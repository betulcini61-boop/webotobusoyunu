<script>
	import { onMount, onDestroy } from 'svelte';

	/** @type {HTMLCanvasElement} */
	let canvas;
	/** @type {CanvasRenderingContext2D} */
	let ctx;
	let wrapEl;

	// --- Sabitler -------------------------------------------------------
	const W = 480;
	const H = 720;
	const LANES = 4;
	const ROAD_MARGIN = 60; // yol dışındaki kaldırım/sahne genişliği
	const ROAD_W = W - ROAD_MARGIN * 2;
	const LANE_W = ROAD_W / LANES;
	const PLAYER_W = LANE_W * 0.62;
	const PLAYER_H = 92;
	const ENEMY_W = LANE_W * 0.62;
	const ENEMY_H = 84;

	const CAR_COLORS = ['#c0392b', '#2e8b57', '#2f6db3', '#2b2b2b', '#d98a2b'];

	// --- Oyun durumu (reaktif olmayan, döngü içinde tutulan) -----------
	let player = { lane: 1, x: 0, y: H - PLAYER_H - 30 };
	let enemies = [];
	let roadOffset = 0;
	let speed = 4.2;
	let spawnTimer = 0;
	let spawnEvery = 70; // frame
	let elapsedFrames = 0;
	let boosting = false;
	let rafId;
	let lastLane = 1;
	let laneChangeT = 1; // 0..1 geçiş animasyonu

	// --- HUD için reaktif değişkenler -----------------------------------
	let score = 0;
	let highScore = 0;
	let gameState = 'menu'; // 'menu' | 'playing' | 'over'

	function laneToX(lane) {
		return ROAD_MARGIN + lane * LANE_W + LANE_W / 2;
	}

	function resetGame() {
		player.lane = 1;
		lastLane = 1;
		laneChangeT = 1;
		enemies = [];
		roadOffset = 0;
		speed = 4.2;
		spawnTimer = 0;
		spawnEvery = 70;
		elapsedFrames = 0;
		score = 0;
		boosting = false;
	}

	function startGame() {
		resetGame();
		gameState = 'playing';
	}

	function endGame() {
		gameState = 'over';
		if (score > highScore) {
			highScore = score;
			try {
				localStorage.setItem('otobusOyunuHighScore', String(Math.floor(highScore)));
			} catch (e) {}
		}
	}

	function moveLane(dir) {
		if (gameState !== 'playing') return;
		const target = player.lane + dir;
		if (target < 0 || target >= LANES) return;
		lastLane = player.lane;
		player.lane = target;
		laneChangeT = 0;
	}

	function setBoost(v) {
		boosting = v;
	}

	// --- Girdi: klavye ----------------------------------------------------
	function onKeyDown(e) {
		if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') moveLane(-1);
		else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') moveLane(1);
		else if (e.key === 'Shift') setBoost(true);
		else if (e.key === ' ' || e.key === 'Enter') {
			if (gameState !== 'playing') startGame();
		}
	}
	function onKeyUp(e) {
		if (e.key === 'Shift') setBoost(false);
	}

	// --- Düşman (trafik) araç üretimi --------------------------------------
	function spawnEnemy() {
		const lane = Math.floor(Math.random() * LANES);
		// aynı anda aynı şeride çok yakın araç koymamaya çalış
		const tooClose = enemies.some((en) => en.lane === lane && en.y < ENEMY_H * 1.6);
		if (tooClose) return;
		enemies.push({
			lane,
			y: -ENEMY_H - Math.random() * 40,
			color: CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)]
		});
	}

	// --- Çizim yardımcıları -------------------------------------------------
	function drawScenery() {
		// gökyüzü
		const sky = ctx.createLinearGradient(0, 0, 0, H);
		sky.addColorStop(0, '#bfe9ef');
		sky.addColorStop(1, '#eef6e9');
		ctx.fillStyle = sky;
		ctx.fillRect(0, 0, W, H);

		// sol/sağ kaldırım + şehir silueti (İstanbul esintili)
		ctx.fillStyle = '#e7ddc2';
		ctx.fillRect(0, 0, ROAD_MARGIN, H);
		ctx.fillRect(W - ROAD_MARGIN, 0, ROAD_MARGIN, H);

		ctx.fillStyle = '#8a4b34';
		for (let i = 0; i < 3; i++) {
			const bx = 6 + i * 18;
			ctx.fillRect(bx, 40, 14, 90);
		}
		ctx.fillStyle = '#5f8f6b';
		for (let i = 0; i < 6; i++) {
			const ty = ((i * 140 + roadOffset * 0.4) % (H + 80)) - 40;
			ctx.beginPath();
			ctx.arc(W - ROAD_MARGIN / 2, ty, 16, 0, Math.PI * 2);
			ctx.fill();
			ctx.fillRect(W - ROAD_MARGIN / 2 - 3, ty, 6, 22);
		}
	}

	function drawRoad() {
		ctx.fillStyle = '#33403f';
		ctx.fillRect(ROAD_MARGIN, 0, ROAD_W, H);

		// şerit çizgileri
		ctx.strokeStyle = 'rgba(255,255,255,0.75)';
		ctx.lineWidth = 4;
		ctx.setLineDash([26, 22]);
		for (let l = 1; l < LANES; l++) {
			const x = ROAD_MARGIN + l * LANE_W;
			ctx.beginPath();
			ctx.moveTo(x, (roadOffset % 48) - 48);
			ctx.lineTo(x, H);
			ctx.stroke();
		}
		ctx.setLineDash([]);

		// kenar çizgileri (kırmızı-beyaz bordür)
		const stripe = 22;
		for (let side = 0; side < 2; side++) {
			const bx = side === 0 ? ROAD_MARGIN - 10 : W - ROAD_MARGIN;
			for (let y = -stripe; y < H + stripe; y += stripe) {
				const yy = ((y + roadOffset) % (stripe * 2)) - stripe;
				ctx.fillStyle = Math.floor((y + roadOffset) / stripe) % 2 === 0 ? '#c0392b' : '#f4f4f4';
				ctx.fillRect(bx, yy, 10, stripe);
			}
		}
	}

	function drawCar(cx, cy, w, h, color, isPlayer) {
		ctx.save();
		ctx.translate(cx, cy);
		ctx.fillStyle = 'rgba(0,0,0,0.18)';
		ctx.beginPath();
		ctx.ellipse(0, h / 2 + 4, w / 2, 8, 0, 0, Math.PI * 2);
		ctx.fill();

		ctx.fillStyle = color;
		roundRect(-w / 2, -h / 2, w, h, 10);
		ctx.fill();

		// cam
		ctx.fillStyle = 'rgba(210,235,240,0.9)';
		roundRect(-w / 2 + 6, -h / 2 + (isPlayer ? 10 : 8), w - 12, h * (isPlayer ? 0.32 : 0.38), 6);
		ctx.fill();

		if (isPlayer) {
			ctx.fillStyle = '#7a3d10';
			roundRect(-w / 2 + 4, h / 2 - 20, w - 8, 12, 4);
			ctx.fill();
		}

		// tekerlekler
		ctx.fillStyle = '#141414';
		const wheelW = 6;
		const wheelH = 16;
		ctx.fillRect(-w / 2 - 2, -h / 2 + 8, wheelW, wheelH);
		ctx.fillRect(-w / 2 - 2, h / 2 - 8 - wheelH, wheelW, wheelH);
		ctx.fillRect(w / 2 - wheelW + 2, -h / 2 + 8, wheelW, wheelH);
		ctx.fillRect(w / 2 - wheelW + 2, h / 2 - 8 - wheelH, wheelW, wheelH);

		ctx.restore();
	}

	function roundRect(x, y, w, h, r) {
		ctx.beginPath();
		ctx.moveTo(x + r, y);
		ctx.arcTo(x + w, y, x + w, y + h, r);
		ctx.arcTo(x + w, y + h, x, y + h, r);
		ctx.arcTo(x, y + h, x, y, r);
		ctx.arcTo(x, y, x + w, y, r);
		ctx.closePath();
	}

	// --- Ana döngü -----------------------------------------------------
	function update() {
		if (gameState === 'playing') {
			elapsedFrames++;
			const curSpeed = speed + (boosting ? 3.2 : 0);
			roadOffset += curSpeed;
			score += curSpeed * 0.045 * (boosting ? 1.4 : 1);

			// zorluk artışı
			speed = 4.2 + elapsedFrames / 900;
			spawnEvery = Math.max(26, 70 - elapsedFrames / 60);

			spawnTimer++;
			if (spawnTimer >= spawnEvery) {
				spawnTimer = 0;
				spawnEnemy();
			}

			laneChangeT = Math.min(1, laneChangeT + 0.22);

			for (const en of enemies) {
				en.y += curSpeed * 1.05;
			}
			enemies = enemies.filter((en) => en.y < H + ENEMY_H);

			// çarpışma kontrolü
			const px = laneToX(player.lane);
			const py = player.y;
			for (const en of enemies) {
				const ex = laneToX(en.lane);
				const ey = en.y;
				const overlapX = Math.abs(px - ex) < (PLAYER_W + ENEMY_W) / 2 - 8;
				const overlapY = Math.abs(py - ey) < (PLAYER_H + ENEMY_H) / 2 - 10;
				if (overlapX && overlapY) {
					endGame();
					break;
				}
			}
		}

		draw();
		rafId = requestAnimationFrame(update);
	}

	function draw() {
		drawScenery();
		drawRoad();

		for (const en of enemies) {
			drawCar(laneToX(en.lane), en.y, ENEMY_W, ENEMY_H, en.color, false);
		}

		const fromX = laneToX(lastLane);
		const toX = laneToX(player.lane);
		const px = fromX + (toX - fromX) * easeOut(laneChangeT);
		drawCar(px, player.y, PLAYER_W, PLAYER_H, '#e8a33d', true);
	}

	function easeOut(t) {
		return 1 - Math.pow(1 - t, 3);
	}

	onMount(() => {
		ctx = canvas.getContext('2d');
		try {
			highScore = Number(localStorage.getItem('otobusOyunuHighScore') || 0);
		} catch (e) {
			highScore = 0;
		}
		window.addEventListener('keydown', onKeyDown);
		window.addEventListener('keyup', onKeyUp);
		rafId = requestAnimationFrame(update);
	});

	onDestroy(() => {
		if (rafId) cancelAnimationFrame(rafId);
		if (typeof window !== 'undefined') {
			window.removeEventListener('keydown', onKeyDown);
			window.removeEventListener('keyup', onKeyUp);
		}
	});
</script>

<svelte:head>
	<title>Otobüs Oyunu</title>
</svelte:head>

<div class="page">
	<header class="topbar">
		<h1>🚌 Otobüs Oyunu</h1>
		<div class="scores">
			<span>Skor: {Math.floor(score)}</span>
			<span>Rekor: {Math.floor(highScore)}</span>
		</div>
	</header>

	<div class="stage" bind:this={wrapEl}>
		<canvas bind:this={canvas} width={W} height={H}></canvas>

		{#if gameState === 'menu'}
			<div class="overlay">
				<h2>Otobüs Oyunu</h2>
				<p>Şeritler arasında geçiş yaparak trafikten kaç.</p>
				<button on:click={startGame}>Başla</button>
				<p class="hint">← → veya A/D · Shift = hızlan</p>
			</div>
		{:else if gameState === 'over'}
			<div class="overlay">
				<h2>Çarptın!</h2>
				<p>Skor: {Math.floor(score)}</p>
				<p>Rekor: {Math.floor(highScore)}</p>
				<button on:click={startGame}>Tekrar Oyna</button>
			</div>
		{/if}
	</div>

	<div class="controls">
		<button
			class="ctrl left"
			on:pointerdown={() => moveLane(-1)}
			aria-label="Sola geç"
		>◀</button>
		<button
			class="ctrl boost"
			on:pointerdown={() => setBoost(true)}
			on:pointerup={() => setBoost(false)}
			on:pointerleave={() => setBoost(false)}
			aria-label="Hızlan"
		>⚡</button>
		<button
			class="ctrl right"
			on:pointerdown={() => moveLane(1)}
			aria-label="Sağa geç"
		>▶</button>
	</div>
</div>

<style>
	:global(html, body) {
		margin: 0;
		height: 100%;
		background: #0e3b39;
		font-family: 'Segoe UI', system-ui, sans-serif;
	}
	.page {
		min-height: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 10px;
		padding: 14px 10px 24px;
		color: #f3ecd9;
		box-sizing: border-box;
	}
	.topbar {
		width: 100%;
		max-width: 480px;
		display: flex;
		justify-content: space-between;
		align-items: baseline;
	}
	.topbar h1 {
		font-size: 1.2rem;
		margin: 0;
	}
	.scores {
		display: flex;
		gap: 12px;
		font-size: 0.9rem;
		opacity: 0.9;
	}
	.stage {
		position: relative;
		width: 100%;
		max-width: 480px;
		aspect-ratio: 480 / 720;
		border-radius: 14px;
		overflow: hidden;
		box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
	}
	canvas {
		width: 100%;
		height: 100%;
		display: block;
	}
	.overlay {
		position: absolute;
		inset: 0;
		background: rgba(14, 30, 29, 0.72);
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 10px;
		text-align: center;
		padding: 20px;
	}
	.overlay h2 {
		margin: 0 0 4px;
	}
	.overlay button {
		background: #e8a33d;
		color: #1a1a1a;
		border: none;
		padding: 10px 26px;
		font-size: 1rem;
		font-weight: 700;
		border-radius: 999px;
		cursor: pointer;
	}
	.hint {
		font-size: 0.8rem;
		opacity: 0.75;
	}
	.controls {
		width: 100%;
		max-width: 480px;
		display: flex;
		gap: 10px;
		margin-top: 4px;
	}
	.ctrl {
		flex: 1;
		padding: 16px 0;
		font-size: 1.3rem;
		border-radius: 12px;
		border: none;
		background: #16504d;
		color: #f3ecd9;
		touch-action: manipulation;
		user-select: none;
	}
	.ctrl.boost {
		background: #c1451b;
		flex: 0.8;
	}
</style>
